In this released, there are no need a loader anymore but you need a trial account or expired account in order to use it. Also the functions creating campaign still not working fine.

Always use the original MoneyRobot before using the crack for login.